<?php

namespace App\Controllers;

use CodeIgniter\Model;

class AufgabenplanerModel extends Model
{
    public function getAllmitglied()
    {
        $result = $this->db->query('SELECT * FROM mitglied order by name');
        return $result->getResultArray();
    }

    public function getAllAufgaben()
    {
        $result = $this->db->query('SELECT * FROM aufgaben order by bezeichnung');
        return $result->getResultArray();
    }

    public function getAllReiter()
    {
        $result = $this->db->query('SELECT * FROM reiter order by bezeichnung');
        return $result->getResultArray();
    }


}


