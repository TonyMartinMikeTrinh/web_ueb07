<?php

namespace App\Controllers;


class Home extends BaseController
{

    public function __construct()
    {
        $this->model = new AufgabenplanerModel();
    }

    public function login()
    {



        if(isset($_POST['email']) && isset($_POST['passwort'])) {
            if($this->model->login() != null) {

            }
        }

        //$this->load->helper('form');
        $data['titel'] = "Aufgabenplaner: Login";
        echo view('templates/header', $data);
        echo view('login');
    }

    public function test(){
        echo view("test");
    }

    public function aktuellesProjekt(){
        $data['titel'] = "Aufgabenplaner: aktuelles Projekt";

        $data['mitglieder'] = $this->getMitglieder();
        $data['Reiter']= $this->getReiter($data);

        $data["getAllmitglied"] = $this->model->getAllmitglied();

        $data["getAllAufgaben"] = $this->model->getAllAufgaben();
        $data["getAllReiter"] = $this->model->getAllReiter();

        echo view('templates/header', $data);
        echo view('aktuellesProjekt');
    }

    public function projekte(){
        $data['titel'] = "Aufgabenplaner: Projekte";
        echo view('templates/header', $data);
        echo view('projekte');
    }

    public function reiter(){
        $data['titel'] = "Aufgabenplaner: Reiter";
        echo view('templates/header', $data);
        echo view('reiter');
    }

    public function aufgaben(){
        $data['titel'] = "Aufgabenplaner: Aufgaben";
        $data['mitglieder'] = $this->getMitglieder();
        $data['Reiter']= $this->getReiter($data);
        echo view('templates/header', $data);
        echo view('aufgaben');
    }

    public function mitglieder(){
        $data['titel'] = "Aufgabenplaner: Personen";
        $data['mitglieder'] = $this->model->getAllmitglied();
        echo view('templates/header', $data);
        echo view('personen');
    }


















    private function getMitglieder(){
        return array(
            array(  'id'=>1,
                'Name'=>'Max Mustermann',
                'Mail'=>'mustermann@muster.de',
                'In Projekt'=>'false'
            ),
            array(  'id'=>2,
                'Name'=>'Petra Müller',
                'Mail'=>'petra@mueller.de',
                'In Projekt'=>'false'
            )
        );
    }

    private function getReiter($data)
    {
        return array(
            array('Aufgabenbezeichnung'=>'HTML Datei erstellen',
                'Beschreibung der Aufgabe'=>'HTML Datei erstellen',
                'Zuständig'=>$data['mitglieder'][0],
                'Reiter'=>"ToDo"
            ),
            array(  'Aufgabenbezeichnung'=>'CSS Datei erstellen',
                'Beschreibung der Aufgabe'=>'HTML Datei erstellen',
                'Zuständig'=>$data['mitglieder'][0],
                'Reiter'=>"ToDo"
            ),
            array(  'Aufgabenbezeichnung'=>'PC eingeschalet',
                'Beschreibung der Aufgabe'=>'PC einschalten',
                'Zuständig'=>$data['mitglieder'][0],
                'Reiter'=>"Erledigt"
            ),
            array(  'Aufgabenbezeichnung'=>'Kaffee trinken',
                'Beschreibung der Aufgabe'=>'Kaffee trinken',
                'Zuständig'=>$data['mitglieder'][1],
                'Reiter'=>"Erledigt"
            ),
            array(  'Aufgabenbezeichnung'=>'Für die Uni lernen',
                'Beschreibung der Aufgabe'=>'Für die Uni lernen.',
                'Zuständig'=>$data['mitglieder'][0],
                'Reiter'=>"Verschoben"
            )
        );
    }

}
