<div class="container-fluid ms-4 me-3 p-2">
    <div class="list-group" style="min-width: max-content">

        <div class="list-group-item" style="font-size:calc(4px + 1vw)">
            <a href="<?=base_url('/Home/login/')?>" style="text-decoration: none">Login</a>
        </div>

        <div class="list-group-item" style="font-size:calc(4px + 1vw)">
            <a href="<?=base_url('/Home/projekte/')?>" style="text-decoration: none">Projekte</a>
        </div>

        <div class="list-group-item" style="font-size:calc(4px + 1vw)">
            <a href="<?=base_url('/Home/aktuellesProjekt/')?>" style="text-decoration: none">Aktuelles Projekt</a>
        </div>

        <div class="list-group-item" style="font-size:calc(4px + 1vw); margin-left: 2vw">
            <a href="<?=base_url('/Home/reiter/')?>" style="text-decoration: none">Reiter</a>
        </div>

        <div class="list-group-item" style="font-size:calc(4px + 1vw); margin-left: 2vw">
            <a href="<?=base_url('/Home/aufgaben/')?>" style="text-decoration: none">Aufgaben</a>
        </div>

        <div class="list-group-item" style="font-size:calc(4px + 1vw); margin-left: 2vw">
            <a href="<?=base_url('/Home/mitglieder/')?>" style="text-decoration: none">Mitglieder</a>
        </div>

    </div>

</div>


